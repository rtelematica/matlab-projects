% fichero patch1.m 
% ejemplo de la funci�n patch en 2D 
clear all 
close all 
x1=[0 1 0]; 
y1=[0 0 2]; 
patch(x1,y1,'g'); 
axis([0,3,0,3]); 